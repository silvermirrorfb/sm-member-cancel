# Upgrade Check QA Runbook

## Endpoint
- `POST /api/qa/upgrade-check`
- Canonical location IDs: see [LOCATION_ID_REGISTRY.md](./LOCATION_ID_REGISTRY.md)

## Auth Headers
- `x-qa-token: <QA_UPGRADE_CHECK_TOKEN>`
- `x-qa-synthetic-token: <QA_SYNTHETIC_MODE_TOKEN>` (required only when `syntheticMode` is used)

## Quick Production Probe (real lookup)
```bash
npx vercel curl /api/qa/upgrade-check -- --request POST \
  --header "Content-Type: application/json" \
  --header "x-qa-token: $QA_UPGRADE_CHECK_TOKEN" \
  --data '{
    "firstName": "Debbie",
    "lastName": "Von Ahrens",
    "email": "debbievonahrens@mac.com",
    "debug": true
  }'
```

## Synthetic Probe (lookup fallback)
```bash
npx vercel curl /api/qa/upgrade-check -- --request POST \
  --header "Content-Type: application/json" \
  --header "x-qa-token: $QA_UPGRADE_CHECK_TOKEN" \
  --header "x-qa-synthetic-token: $QA_SYNTHETIC_MODE_TOKEN" \
  --data '{
    "syntheticMode": "lookup",
    "firstName": "Sandra",
    "lastName": "Bellew",
    "email": "sandra.bellew+qa@gmail.com",
    "syntheticCandidates": [
      { "id": "urn:blvd:Client:1", "firstName": "Sandra", "lastName": "Bellew", "email": "sandra.bellew@icloud.com" }
    ]
  }'
```

## Synthetic Probe (eligibility math)
```bash
npx vercel curl /api/qa/upgrade-check -- --request POST \
  --header "Content-Type: application/json" \
  --header "x-qa-token: $QA_UPGRADE_CHECK_TOKEN" \
  --header "x-qa-synthetic-token: $QA_SYNTHETIC_MODE_TOKEN" \
  --data '{
    "syntheticMode": "eligibility",
    "firstName": "Jane",
    "lastName": "Smith",
    "email": "jane@example.com",
    "targetDurationMinutes": 50,
    "now": "2026-03-09T17:00:00Z",
    "syntheticProfile": {
      "id": "urn:blvd:Client:jane",
      "firstName": "Jane",
      "lastName": "Smith",
      "email": "jane@example.com",
      "membershipTier": "30",
      "accountStatus": "ACTIVE",
      "locationId": "urn:blvd:Location:24a2fac0-deef-4f7f-8bf6-52368be42d65"
    },
    "syntheticAppointments": [
      {
        "id": "appt-1",
        "clientId": "urn:blvd:Client:jane",
        "startOn": "2026-03-09T18:00:00Z",
        "endOn": "2026-03-09T18:30:00Z",
        "locationId": "urn:blvd:Location:24a2fac0-deef-4f7f-8bf6-52368be42d65"
      }
    ]
  }'
```

## Idempotency Probe
Use a unique key per test run.
```bash
npx vercel curl /api/qa/upgrade-check -- --request POST \
  --header "Content-Type: application/json" \
  --header "x-qa-token: $QA_UPGRADE_CHECK_TOKEN" \
  --header "x-idempotency-key: qa-test-001" \
  --data '{"firstName":"Debbie","lastName":"Von Ahrens","email":"debbievonahrens@mac.com"}'
```

## Expected Headers
- `X-Request-Id`
- `X-RateLimit-Limit`
- `X-RateLimit-Remaining`
- `X-Idempotency-Key` (when provided)
- `X-Idempotency-Replayed` (when replayed)

## Common Failure Modes
- `401 Unauthorized`: wrong or stale `x-qa-token`.
- `401 Unauthorized synthetic mode`: missing/wrong `x-qa-synthetic-token`.
- `404 member_not_found`: Boulevard lookup miss or transient upstream issue.
- `429 Too many requests`: use throttling in batch QA.

## Safe Batch Cadence
- Keep batch requests at `~5s` spacing to avoid QA route limits.

## SMS Endpoints
- Twilio inbound webhook: `POST /api/sms/twilio/webhook`
- Pre-appointment outbound automation: `POST /api/sms/automation/pre-appointment`

### Twilio inbound requirements
- Point the Twilio phone number's incoming message webhook to your deployed app, for example:
  `https://sm-member-cancel.vercel.app/api/sms/twilio/webhook`
- Twilio should send form-encoded payload with `From`, `Body`, and `MessageSid`.
- Signature validation is enforced via `X-Twilio-Signature`; set `TWILIO_AUTH_TOKEN` in production or inbound SMS will be rejected.
- Current safe launch posture is `SMS_UPGRADE_STATUS=pending`:
  - inbound SMS handles general Q&A only,
  - upgrade-related SMS replies tell the guest to call `(888) 677-0055`,
  - no SMS upgrade offer should be treated as live until Boulevard API readiness is confirmed.

### Outbound automation request
```bash
npx vercel curl /api/sms/automation/pre-appointment -- --request POST \
  --header "Content-Type: application/json" \
  --header "x-automation-token: $SMS_AUTOMATION_TOKEN" \
  --data '{
    "dryRun": true,
    "now": "2026-03-09T17:00:00Z",
    "windowHours": 6,
    "sendTimezone": "America/New_York",
    "sendStartHour": 9,
    "sendEndHour": 17,
    "candidates": [
      {
        "firstName": "Debbie",
        "lastName": "Von Ahrens",
        "email": "debbievonahrens@mac.com"
      }
    ]
  }'
```

### Outbound send controls
- `windowHours`: eligibility window before appointment (default `6`).
- `sendTimezone`: timezone for send-hour guardrail (default `America/New_York`).
- `sendStartHour` / `sendEndHour`: allowed send range in 24h format (`9` to `17` = 9:00 AM to 4:59 PM).
- `enforceKlaviyoOptIn` (default `true`): require Klaviyo SMS marketing consent before outbound SMS is sent.
- `liveApproval` (default `false`): required for any non-dry-run live send while manual lock is enabled.
- `enforceSendWindow`: set `false` to bypass send-hour guardrail for QA-only checks.
- `queueWhenOutsideWindow` (default `true`): if outside send hours, queue candidates for next send window instead of dropping them.
- `processQueued` (default `true`): when in-window, automatically drain due queued items and process them.
- `useQueuedOnly` (default `false`): process only queued items (no direct candidates required).
- `maxQueueDrain`: cap number of queued items processed in one run.
- `enableOneHourReminder` (default `true`): enables one follow-up reminder near one hour before appointment, only if prior offer exists and no YES/NO outcome was recorded.
- `reminderLeadMinutes` (default `60`): target lead time for reminder.
- `reminderToleranceMinutes` (default `15`): acceptable drift window around `reminderLeadMinutes`.
- SMS responses are sanitized to plain ASCII and capped (`SMS_MAX_CHARS`, default `155`) so outbound and TwiML replies stay single-text friendly.
- `SMS_WEB_HANDOFF_MESSAGE_LIMIT` (default `10`): after this many inbound SMS messages in one thread, bot replies with web-chat handoff URL.
- `SMS_WEB_APP_URL` (default `https://sm-member-cancel.vercel.app/widget`): destination URL for the 10-message handoff.
- `SMS_UPGRADE_STATUS` (default `pending`): keep SMS upgrade-by-text disabled until Boulevard/API readiness is confirmed; set to `live` only when the SMS upgrade flow is approved for launch.

### Klaviyo opt-in source of truth (required)
- Outbound SMS route checks Klaviyo profile `subscriptions.sms.marketing`.
- SMS is allowed only when:
  - `consent = SUBSCRIBED`
  - `can_receive_sms_marketing` is not `false`
- If Klaviyo is missing/unreachable/not subscribed, route fails closed and returns `status: "skipped"` with a Klaviyo reason code.

Required env vars:
- `TWILIO_AUTH_TOKEN` for inbound signature validation
- `TWILIO_ACCOUNT_SID` and `TWILIO_FROM_NUMBER` for outbound sends
- `KLAVIYO_PRIVATE_API_KEY`
- `KLAVIYO_API_BASE_URL` (optional override, default `https://a.klaviyo.com/api`)
- `KLAVIYO_REVISION` (optional override, default `2026-01-15`)
- `SMS_UPGRADE_STATUS` (optional, default `pending`)
- `SMS_REQUIRE_KLAVIYO_OPT_IN` (optional, default `true`)
- `SMS_REQUIRE_MANUAL_LIVE_APPROVAL` (optional, default `true`)
- `SMS_ENABLE_ONE_HOUR_REMINDER` (optional, default `true`)
- `SMS_REMINDER_LEAD_MINUTES` (optional, default `60`)
- `SMS_REMINDER_TOLERANCE_MINUTES` (optional, default `15`)

### Reminder suppression behavior
- Reminder is skipped if appointment state is already resolved:
  - `already_upgraded`
  - `offer_declined`
  - `reminder_already_sent`
- Initial offer is skipped if:
  - `offer_already_pending`
  - `offer_already_sent`
