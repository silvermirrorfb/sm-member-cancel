# AI Takeover Export

## Purpose

This bundle is a handoff package for another AI agent to take over the Silver Mirror cancel bot / SMS upsell system without reconstructing context from scratch.

It includes:

- a clean snapshot of the repo's non-generated source files
- all tracked and currently untracked docs/specs/logs present in this workspace
- git metadata exports
- file manifests
- a concise operator summary of the current production state and known next priorities

It intentionally excludes generated folders and local secrets.

## Canonical Repo Identity

- Canonical repo path in this workspace: `/Users/mattmaroone/Documents/Cancel-Bot-Codex`
- Working path used in this session: `/Users/mattmaroone/Documents/New project`
- GitHub remote: `https://github.com/silvermirrorfb/sm-member-cancel.git`
- Branch at export time: `main`
- HEAD at export time: `10c953e2a3ef934e6a7b9465ea10c83db665ed1e`
- Export date: `2026-03-28`
- Export timezone: `America/New_York`

## What This System Does

This repo started as the Silver Mirror membership cancellation assistant and now also contains the live SMS pre-appointment upsell / add-on automation flow.

High-level product surfaces:

- Web cancellation chat widget
- Chat API routes for member support / retention
- Boulevard member lookup and booking logic
- Twilio inbound / outbound SMS flow
- SMS pre-appointment automation route
- QA upgrade-check route for deterministic diagnostics
- Email / Google Sheets logging
- Shared rate limiting for production routes

## Production State At Export Time

The most important live facts to carry forward:

- Production app: `https://sm-member-cancel.vercel.app`
- March 28, 2026 completed a real live Matt Maroone end-to-end SMS duration-upgrade proof.
- March 28, 2026 also completed a real live Matt Maroone add-on upsell repair.
- The add-on mutation path is live and uses Boulevard booking primitives:
  - `bookingCreateFromAppointment`
  - `bookingAddServiceAddon`
  - `bookingComplete`
- The inbound Twilio `YES` session-recovery bug across serverless instances was fixed the same day.
- Final verified Matt appointment state from the log:
  - appointment: `urn:blvd:Appointment:4141b2ae-3554-4a37-a104-8277d67692fe`
  - booked window: `4:00 PM -> 5:15 PM ET`
  - services: `Sensitive Skin Facial` + `Antioxidant Peel`

The March 28 commit chain to understand first:

- `48e8ea9` — Recover provider identity for SMS upgrade rebooking
- `ccabb1a` — Recover addon gap context for 50-minute SMS offers
- `0406f72` — Recover inbound SMS session context across instances
- `8ff115e` — Apply SMS add-ons to Boulevard bookings
- `10c953e` — Log March 27-28 SMS bot work

## Read In This Order

If another AI only reads a few files first, use this order:

1. `repo_snapshot/README.md`
2. `repo_snapshot/UPGRADE_SYSTEM_SUMMARY.md`
3. `repo_snapshot/docs/THREAD_HANDOFF_LOG.md`
4. `repo_snapshot/docs/SESSION_ACTIVITY_LOG_2026-03-28.md`
5. `repo_snapshot/.env.example`
6. `repo_snapshot/src/app/api/sms/twilio/webhook/route.js`
7. `repo_snapshot/src/app/api/sms/automation/pre-appointment/route.js`
8. `repo_snapshot/src/lib/boulevard.js`
9. `repo_snapshot/__tests__/twilio-webhook-route.test.js`
10. `repo_snapshot/__tests__/boulevard.test.js`

## Key Code Areas

- `repo_snapshot/src/lib/boulevard.js`
  - Boulevard client
  - appointment scanning
  - gap evaluation
  - cancel / rebook logic
  - add-on mutation path
- `repo_snapshot/src/app/api/sms/automation/pre-appointment/route.js`
  - outbound SMS candidate selection
  - duration vs add-on offer routing
  - dry-run / live send logic
- `repo_snapshot/src/app/api/sms/twilio/webhook/route.js`
  - Twilio signature validation
  - YES / NO handling
  - session recovery
  - live apply path
- `repo_snapshot/src/app/api/chat/message/route.js`
  - chat route deterministic fast paths
  - proactive upgrade offer logic
- `repo_snapshot/src/lib/sms-sessions.js`
  - shared SMS session storage behavior
- `repo_snapshot/src/lib/sms-upgrade-policy.js`
  - `SMS_UPGRADE_STATUS` gating
- `repo_snapshot/src/app/api/qa/upgrade-check/route.js`
  - deterministic QA diagnostics

## Key Docs / Specs / Logs

- `repo_snapshot/docs/THREAD_HANDOFF_LOG.md`
  - running cross-session summary
- `repo_snapshot/docs/SESSION_ACTIVITY_LOG_2026-03-28.md`
  - full detailed record of the major live fixes and proofs
- `repo_snapshot/docs/SESSION_ACTIVITY_LOG_2026-03-27.md`
  - negative-evidence log for that day
- `repo_snapshot/docs/SESSION_ACTIVITY_LOG_2026-03-12.md`
  - earlier SMS work and blocker history
- `repo_snapshot/docs/THREAD_RECOVERY_2026-03-12.md`
  - thread reconstruction notes
- `repo_snapshot/docs/THREAD_TRANSCRIPT_RECOVERED_2026-03-11.md`
  - recovered prior thread content
- `repo_snapshot/docs/CODEX_TECHNICAL_CHANGELOG_2026-03-02.md`
- `repo_snapshot/docs/CODEX_TECHNICAL_CHANGELOG_2026-03-02_PART2.md`
- `repo_snapshot/docs/CODEX_TECHNICAL_CHANGELOG_2026-03-06_PART3.md`
  - longer technical narrative / prior implementation history
- `repo_snapshot/docs/OUTBOUND_SMS_LOGIC_PLAIN_ENGLISH.md`
  - business-logic explanation
- `repo_snapshot/docs/OUTBOUND_SMS_DRYRUN_MATRIX_2026-03-09.md`
- `repo_snapshot/docs/OUTBOUND_SMS_DRYRUN_MATRIX_2026-03-11.md`
  - past QA run artifacts
- `repo_snapshot/docs/LOCATION_ID_REGISTRY.md`
  - Boulevard location mapping context
- `repo_snapshot/docs/QA_UPGRADE_CHECK_RUNBOOK.md`
  - QA route usage
- `repo_snapshot/docs/Silver Mirror SMS Upgrade Decision Tree - 031026 .docx`
  - spec artifact preserved as-is
- `repo_snapshot/docs/SMS_Text_Message_Catalog_2026-03-10.csv`
  - copy inventory

## Environment / Runtime Surface

Use `repo_snapshot/.env.example` as the authoritative env surface included in this export.

Major env groups:

- Anthropic
- Boulevard admin API
- SMTP
- Google Sheets
- Upstash shared rate limiting
- SMS upgrade / add-on tuning
- Twilio
- Klaviyo opt-in gating
- QA route auth tokens

Secrets are intentionally not exported in this package.

## What Is Included

- all source code in `src/`
- all tests in `__tests__/`
- all docs in `docs/`
- public assets in `public/`
- helper scripts in `scripts/`
- top-level config / metadata files
- `.external/mirrosa-kiosk/` because it exists in the workspace and may matter to future operations
- current untracked docs/spec files present in this workspace
- git history / status / manifest exports in this bundle

## What Is Excluded

Excluded on purpose because another AI does not need them to take over safely:

- `.git/`
- `node_modules/`
- `.next/`
- `.vercel/`
- local secret files such as `.env.local` if present
- OS noise like `.DS_Store`

See `manifests/EXCLUDED_FROM_EXPORT.txt` for the exact exclusion list.

## Suggested First Actions For The Next AI

1. Read the handoff log and March 28 session log before making any assumptions.
2. Confirm current production env gates before touching SMS behavior:
   - `SMS_UPGRADE_STATUS`
   - `BOULEVARD_ENABLE_UPGRADE_MUTATION`
   - `BOULEVARD_ENABLE_CANCEL_REBOOK_FALLBACK`
3. If continuing SMS work, inspect:
   - add-on copy quality
   - add-on eligibility edge cases
   - customer-facing wording for proactive messages
4. Use the QA route before any live guest-facing send when possible.
5. Treat March 28 logs as the latest trustworthy live proof in this workspace.

## Export Folder Map

- `repo_snapshot/`
  - copied non-generated repo files
- `git_meta/`
  - branch, remotes, status, log exports
- `manifests/`
  - file lists and exclusion notes

## Notes

- This export is meant for operational continuity, not for reproducing secrets or deployment credentials.
- If a later AI needs exact production env values, it must retrieve them from the live deployment environment rather than this bundle.
